# expose functions for routers to import
from .extractor import extract_text_from_file  # noqa: F401
from .reference import extract_reference_text  # noqa: F401
