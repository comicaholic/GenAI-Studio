export default function CustomPagesIndex() {
  return <div style={{ padding: 16 }}><h2>CustomPagesIndex</h2><p>TODO: Implement page UI.</p></div>
}
