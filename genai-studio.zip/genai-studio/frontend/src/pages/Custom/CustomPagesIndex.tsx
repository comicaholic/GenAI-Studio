export default function CustomPagesIndex() {
  return <div style={{ padding: 16 }}><h2 className="text-lg font-semibold text-neutral-900 dark:text-neutral-100">CustomPagesIndex</h2><p>TODO: Implement page UI.</p></div>
}
